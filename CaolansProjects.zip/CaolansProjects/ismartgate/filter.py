from bs4 import BeautifulSoup

# Read the HTML file
with open('filter.html', 'r') as file:
    data = file.read()

# Parse the HTML and extract option names
soup = BeautifulSoup(data, 'html.parser')
option_texts = [option.text for option in soup.find_all('option')]

# Print the option texts
for text in option_texts:
    print(text)