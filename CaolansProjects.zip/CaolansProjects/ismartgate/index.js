const manufacturerSelect = document.querySelector('.select-manufacturer select');
const modelSelect = document.querySelector('.select-model select');
const images = document.querySelectorAll('.image-select img');
const firstImage = document.querySelector('.image-select img:first-child');
const secondImage = document.querySelector('.image-select img:nth-child(2)');


manufacturerSelect.addEventListener('change', function() {
    for (let option of modelSelect.options) {
      option.hidden = true;
    }


    
  
    if (manufacturerSelect.value === '1') {
    modelSelect.querySelector('option[value="1"]').hidden = false;
    modelSelect.querySelector('option[value="2"]').hidden = false;
    modelSelect.querySelector('option[value="3"]').hidden = false;
    modelSelect.querySelector('option[value="4"]').hidden = false;
    modelSelect.querySelector('option[value="5"]').hidden = false;
    modelSelect.querySelector('option[value="6"]').hidden = false;
    modelSelect.querySelector('option[value="7"]').hidden = false;
    modelSelect.querySelector('option[value="8"]').hidden = false;
    modelSelect.querySelector('option[value="9"]').hidden = false;
    modelSelect.querySelector('option[value="10"]').hidden = false;
    }
  });
  
  modelSelect.addEventListener('change', function() {


    if (manufacturerSelect.value ==='0' && modelSelect.value==='0') {
        firstImage.style.display = 'block';
        secondImage.style.display = 'block';
    }

   
    if (manufacturerSelect.value === '1' && modelSelect.value === '1') {
        firstImage.style.display = 'block';
        secondImage.style.display = 'block';
      } else {
        firstImage.style.display = 'none';
        secondImage.style.display = 'block';
      }
    });


 
    

  






