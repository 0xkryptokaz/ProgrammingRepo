const manufacturerSelect = document.getElementById('manufacturerSelect');
const modelSelect = document.getElementById('modelSelect');
const carImagesContainer = document.getElementById('carImagesContainer');


fetch('http://localhost:3000/api/items') 
  .then(response => response.json())
  .then(data => {
    const carData = data;
  
  })
  .catch(error => {
    console.error('Error fetching the JSON file', error);
  });



const carData = {
  "toyota": ['Camry', 'Corolla', 'Rav4'],
  "ford": ['Fusion', 'Focus', 'Escape'],
  "honda": ['Accord', 'Civic', 'CR-V'],
};

for (const manufacturer in carData) {
  const manufacturerOption = document.createElement('option');
  manufacturerOption.value = manufacturer.toLowerCase(); 
  manufacturerOption.text = manufacturer;
  manufacturerSelect.add(manufacturerOption);
}

function updateModels() {
  const selectedManufacturer = manufacturerSelect.value.toLowerCase(); 
  const models = carData[selectedManufacturer] || [];


  modelSelect.innerHTML = '';
  carImagesContainer.innerHTML = ''; 

  if (selectedManufacturer !== 'selectManufacturer') {
    modelSelect.disabled = false;

    models.forEach(modelText => {
      const modelOption = document.createElement('option');
      modelOption.value = modelText.toLowerCase();
      modelOption.text = modelText;
      modelSelect.add(modelOption);
    });

    models.forEach(model => {
      const imageContainer = document.createElement('div');
      imageContainer.className = 'image-container';

      const carImage = document.createElement('img');
      carImage.src = `images/${model.toLowerCase()}.png`;
      carImage.alt = `${model} Image`;

      imageContainer.appendChild(carImage);
      carImagesContainer.appendChild(imageContainer);
    });
  } else {
    modelSelect.disabled = true;
  }
}

updateModels();

function handleManufacturerChange() {
  updateModels();
}

function handleSelectionChange(selectBox) {
  console.log(`Selected value in ${selectBox.id}: ${selectBox.value}`);
}


