from faker import Faker
import random
import pandas as pd

# Set up the Faker generator
fake = Faker()

# Generate a list of manufacturers
manufacturers = [fake.company() for _ in range(10)]  # Change 10 to the desired number of manufacturers

# Generate a list of models for each manufacturer
models_per_manufacturer = 3  # Change 3 to the desired number of models per manufacturer
models = [fake.word() for _ in range(len(manufacturers) * models_per_manufacturer)]

# Pair manufacturers with models
data = {'Manufacturer': sum([[manufacturer] * models_per_manufacturer for manufacturer in manufacturers], []),
        'Models': models}

# Create a DataFrame
df = pd.DataFrame(data)

# Save DataFrame to a CSV file
df.to_csv('manufacturers_and_models.csv', index=False)

