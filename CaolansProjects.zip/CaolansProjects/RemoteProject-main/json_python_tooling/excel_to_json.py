import pandas as pd

# Read Excel file into a Pandas DataFrame
excel_file_path = 'path/to/your/excel/file.xlsx'
df = pd.read_excel(excel_file_path)

# Convert DataFrame to JSON
json_data = {
    'manufacturers': [
        {'name': row['Manufacturer'], 'models': row['Models'].split(',')} for _, row in df.iterrows()
    ]
}

# Save JSON data to a file
json_file_path = ''
with open(json_file_path, 'w') as json_file:
    json_file.write(pd.Series([json_data]).to_json(orient='values'))

