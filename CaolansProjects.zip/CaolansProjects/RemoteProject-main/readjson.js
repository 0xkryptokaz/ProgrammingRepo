

const sample = require('./data.json');
console.log(sample);
